# -*- coding: utf-8 -*-
"""
JHT算法激励器客户端示例程序
包含功能：
    1）与服务端的数据交互逻辑
    2）数据转换：网络通信数据<->本地数据
可在CAlgo4Test中嵌入各自算法处理逻辑
"""

class CChatMsg:
    '''
    JHT数据激励器消息格式定义：
    | 数据序列号 | 有效数据长度 | 有效数据 |
    |  8*char   |    8*char    |  N*char |
    所有数据均为文本字符形式，接收方负责转换为自身需要的数据格式
    '''
    def formatSeriesNo(self, a_SeriesNo):
        return "{t_No:08d}".format(t_No=a_SeriesNo)
    def fieldLen4SeriesNo(self):
        return 8
    def formatContentLen(self, a_ContenLen):
        return "{t_Len:08d}".format(t_Len=a_ContenLen)
    def fieldLen4ContentLen(self):
        return 8

import socket
import time

class CAlgoStimuConnection:
    '''
    与远程激励器的交互连接
    '''
    def __init__(self, a_IP, a_Port, a_RecvBufSize, a_SendBufSize):
        self.m_RemoteIP = a_IP
        self.m_RemotePort = a_Port
        # 1.创建socket
        self.m_Socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.m_Socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, a_RecvBufSize)
        self.m_Socket.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, a_SendBufSize)
        # 2. 链接服务器
        while True:
            try:
                self.m_Socket.connect((self.m_RemoteIP, self.m_RemotePort))
            except Exception as e:
                print(e)
            else:
                print("Connected with {t_Port}@{t_IP}".format(
                        t_Port=self.m_RemotePort, t_IP=self.m_RemoteIP))
                break;
    def __del__(self):
        # 4. 关闭套接字
        self.m_Socket.close()
    def recv(self, a_LinkSpeed):
        #接收序列号
        self.m_CurSeriesNo = self.m_Socket.recv(CChatMsg().fieldLen4SeriesNo()).decode();
        #接收数据长度
        t_ContentLen = self.m_Socket.recv(CChatMsg().fieldLen4ContentLen()).decode();
        print("Recv from server: SeriesNo={t_No}, Len={t_Len}"\
                .format(t_No=self.m_CurSeriesNo, t_Len=t_ContentLen))
        t_ContentLen = int(t_ContentLen)
        #接收前等待Socket接收数据完毕，否则读取到的数据可能存在错误
        #根据单时间片内接收数据大小不同，等待时长可配置为不同值
        #按照网络速度计算等待时长
        if a_LinkSpeed > 0:
            time.sleep(float(t_ContentLen)/a_LinkSpeed)
        #接收数据内容
        t_Content = self.m_Socket.recv(t_ContentLen).decode();
        return t_Content
    def send(self, a_Results):
        #发送序列号（原样返回，通知服务端这是对上一帧数据的反馈，双方进入下一时间片交互）
        self.m_Socket.send(self.m_CurSeriesNo.encode())
        #发送数据长度
        t_ContentLen = CChatMsg().formatContentLen(len(a_Results))
        self.m_Socket.send(t_ContentLen.encode())
        #发送处理结果
        self.m_Socket.send(a_Results.encode());
        print("Send to server: SeriesNo={t_No}, Len={t_Len}, Content=\n{t_Cont}"\
                .format(t_No=self.m_CurSeriesNo, t_Len=t_ContentLen, t_Cont=a_Results))
    def doChat(self, a_Operator, a_LinkSpeed):
        #必须发送第一帧，触发服务器进入文件数据交互模式
        self.m_CurSeriesNo = CChatMsg().formatSeriesNo(1)
        self.send("This is the first frame from PYTHON client")
        while True:
            #接收
            try:
                t_Content = self.recv(a_LinkSpeed)
            except Exception as e:
                print(e)
                raise e
            #处理
            t_Results = a_Operator.proc(t_Content)
            #反馈
            try:
                self.send(t_Results)
            except Exception as e:
                print(e)
                raise e

class CMsgFormat:
    '''
    消息文本数据转换
    '''
    def SplitCharArrayIntoMat(self, a_Srcs):
        t_Mat = []
        t_Lines = a_Srcs.split('\n')
        for t_Index4Line in range(len(t_Lines)):
            t_Line = t_Lines[t_Index4Line]
            t_Cols = self.SplitLine(t_Line)
            if t_Cols:
                for t_Index4Col in range(len(t_Cols)):
                    t_Cols[t_Index4Col] = float(t_Cols[t_Index4Col])
                t_Mat.append(t_Cols)
        return t_Mat
    def SplitLine(self, a_Line):
        #首先按照空白字符分割
        t_Cols = a_Line.split()
        if t_Cols:
            if 1==len(t_Cols):
                #没有完成分割，则按照csv格式分割
                t_Cols = a_Line.split(',')
        return t_Cols
    def ConcatMatIntoCharArray(self, a_Mat):
        if a_Mat == ' ':
            return 'wait'
        else:
            t_Line = "\n".join(
                            [
                                " ".join(["{t_V:.9f}".format(t_V=a_Mat[t_Index4Row][t_Index4Col]) for t_Index4Col in range(len(a_Mat[t_Index4Row]))]) for t_Index4Row in range(len(a_Mat))
                            ]
                        )
            t_Line = ';'.join(t_Line.split('\n'))
            t_Line = ','.join(t_Line.split(' '))
            return t_Line

class CAlgo4Test:
    '''
    算法处理
    '''
    def proc(self, a_Srcs):
        #print('\n'.join(["Receive:", a_Srcs]))
        t_AlgoInput = CMsgFormat().SplitCharArrayIntoMat(a_Srcs)
        # t_AlgoOutput = t_AlgoInput
        t_AlgoOutput = [[1234,9001,10,9002,12],
                        [1234,9001,10,9002,12],
                        [1234,9001,10,9002,12],
                        [1234,9001,10,9002,12]]
        # t_AlgoOutput = ' '
        #返回数据格式：
        #1.没有数据返回时，t_AlgoOutput = ' '(空字符)
        #2.有数据返回时，按照以下格式：
        #           [[时间，信源号，航迹批号，信源号，航迹批号],
        #            [时间，信源号，航迹批号，信源号，航迹批号],
        #            [时间，信源号，航迹批号，信源号，航迹批号],
        #            [时间，信源号，航迹批号，信源号，航迹批号]]
        t_Ret = CMsgFormat().ConcatMatIntoCharArray(t_AlgoOutput)
        #print('\n'.join(["Proc results:", t_Ret]))
        return t_Ret

import sys

if __name__ == '__main__':
    t_ServerIP = "127.0.0.1"
    if len(sys.argv)>1:
        t_ServerIP = sys.argv[1]
    t_ServerPort = 29853
    if len(sys.argv)>2:
        t_ServerPort = int(sys.argv[2])
    t_Conn = CAlgoStimuConnection(t_ServerIP, t_ServerPort, 
                                  1*1024*1024, 1*1024*1024)
    t_Conn.doChat(CAlgo4Test() , 1*1024*1024)
